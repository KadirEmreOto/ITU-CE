/*
 * Author: Kadir Emre Oto
 * Student ID: 150140032
 * Homework #2: Adder and Remover
 */

#include "Node.hpp"

Node::Node(int x): value(x){
    next = NULL;
    prev = NULL;
}
