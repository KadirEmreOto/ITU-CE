/************************************************************************
*																		*
* ders 10 ornekleri - Deniz Demiray										*
* char dizi ornegi 2, & olmayan scanf ve char ptr ile string yazimi		*
* derlemek icin gcc -o program_ismi 2.c									*
*																		*
************************************************************************/

#include <stdio.h>

int main()
{
	char kelime[15], *ptr;
	
	printf("Bir kelime giriniz: ");
	scanf("%s", kelime);
	printf("%s\n", kelime);
	
	for (ptr = kelime; *ptr != '\0'; ptr++){
		printf("%c", *ptr);	
	};
	printf("\n");
		
	while (ptr-- != kelime) {
		printf("%c", *ptr);
	} ;
    printf("\n");
    
	return 0;
}
