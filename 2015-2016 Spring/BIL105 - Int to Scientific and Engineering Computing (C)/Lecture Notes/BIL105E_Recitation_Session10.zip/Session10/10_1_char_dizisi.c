/************************************************************************
*																		*
* ders 10 ornekleri - Deniz Demiray										*
* char dizi ornegi 1, 										*
* derlemek icin gcc -o program_ismi 1.c									*
*																		*
************************************************************************/

#include <stdio.h>

int main()
{
	char kelime[] = {'d', 'e', 'n', 'e', 'm', 'e','\0'};
	
	printf("%s\n", kelime);

	return 0;
}
