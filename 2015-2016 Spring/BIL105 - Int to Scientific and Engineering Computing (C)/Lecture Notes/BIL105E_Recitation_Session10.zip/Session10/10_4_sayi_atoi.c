/************************************************************************
*																		*
* ders 10 ornekleri - Deniz Demiray										*
* string sayinin karesini alan program									*
* derlemek icin gcc -o program_ismi 6.c									*
*																		*
************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	char sayi_str[5];
	int sayi_int;
	
	printf("Sayiyi giriniz: ");
	scanf("%s", sayi_str);
	
	printf("Girilen string: %s\n", sayi_str);
	
	sayi_int = atoi (sayi_str);
	printf("Sayi hali: %d\n", sayi_int);
	printf("Karesi: %d\n", sayi_int * sayi_int);
	
	return 0;
}
