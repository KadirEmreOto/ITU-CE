/************************************************************************
*																		*
* ders 10 ornekleri - Deniz Demiray										*
* string uzunlugu bulup kopyalayan program								*
* derlemek icin gcc -o program_ismi 7.c									*
*																		*
************************************************************************/

#include <stdio.h>
#include <string.h>

int main()
{
	char cumle[20], kopya[20];
	
	printf("Bir cumle giriniz: ");
	fgets(cumle, 20, stdin);
	printf("Girilen cumle: %s\n", cumle);
	printf("Uzunlugu: %d\n", (int)strlen(cumle));
	
	strcpy(kopya, cumle);
	printf("kopyasi: %s\n", kopya);
	
	return 0;
}
