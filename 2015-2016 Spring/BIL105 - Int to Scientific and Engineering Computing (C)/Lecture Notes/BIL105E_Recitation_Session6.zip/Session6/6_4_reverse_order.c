#include <stdio.h>

int main (void) {
	int i, readNum;
	int numbers[50];

	printf("You may enter up to 50 integers:\n");
	printf("How many would you like to enter? ");
	scanf ("%d", &readNum);
	
	if (readNum > 50)
	    readNum = 50;
	
	// Fill the array 
	printf("\nEnter your numbers: \n");
	for (i = 0; i < readNum; i++)
	     scanf("%d", &numbers[i]);
	     
	// Print the array 
	printf("\nYour numbers reversed are:");
	for ( i = readNum - 1; i >= 0; i--) {
	    printf("%3d", numbers[i]);
	} // for 

        printf("\n");	   
	return 0;
}	// main 

