//
//  main.c
//  Homework3
//
//  Created by Kadir Emre OTO on 09/05/2017.
//  Copyright © 2017 Kadir Emre OTO. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
