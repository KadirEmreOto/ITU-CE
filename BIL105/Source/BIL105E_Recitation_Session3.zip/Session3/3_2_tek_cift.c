/******************************************************************
* ornek   : 3-2                                                	  *
* aciklama: girilen sayinin tek mi cift mi oldugunu bulan program *
* derleme : gcc -o program_ismi 3_2_tek_cift.c         	          *
******************************************************************/

#include <stdio.h>

int main() {	
   int sayi;
  
   printf("Bir sayi giriniz:");
   scanf("%d", &sayi);

   /*
   if ((sayi % 2) == 0) 
      printf("Sayi cifttir\n");
   else
      printf("Sayi tektir\n");
   */

//(sayi % 2) == 0 ? printf("Sayi cifttir\n") : printf("Sayi tektir\n");

   printf(!(sayi % 2) ? "Sayi cifttir\n": "Sayi tektir\n");

   return 0; 
}
