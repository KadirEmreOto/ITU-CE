/****************************************************************
* ornek   : 3-12						*
* aciklama: girilen karaktere ve yukseklige gore ucgen cizme	*
* derleme : gcc -o program_ismi 3_12_ucgen.c			*
****************************************************************/

#include <stdio.h>

int main() {
   char sekil;
   int  yukseklik, i, j;

   printf("Sekili olusturacak karakteri ve yuksekligi giriniz: ");
   scanf("%c %d", &sekil, &yukseklik);

   for (i = 1; i <= yukseklik; i++) {
      for (j = 0; j < yukseklik - i; j++) printf(" ");
      for (j = 0; j < (2*i) - 1;     j++) printf("%c", sekil);
      printf("\n");
   }

   return 0;
}
