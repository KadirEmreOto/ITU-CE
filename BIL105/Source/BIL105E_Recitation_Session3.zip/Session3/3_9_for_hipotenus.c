/************************************************************
* ornek   : 3-9						    *
* aciklama: dik ucgenin hipotenusunu bulan program	    *
* derleme : gcc -lm -o program_ismi 3_9_for_hipotenus.c     *
************************************************************/

#include <math.h>
#include <stdio.h>

int main() {
	
   int a, b;
	
   for (;;) {
      printf("iki kenari giriniz:");
      scanf("%d %d", &a, &b);
	
      if (a > 0 && b > 0) {
         printf("sonuc: %.2f\n", pow(a*a+b*b, 0.5));
         break;
      }
      else
         printf("farkli degerler giriniz...\n");
   }
	
   return 0;
	
}

