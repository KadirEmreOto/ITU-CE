/***********************************************************
* ornek   : 3-3                               	    	   *
* aciklama: sayinin 5 ve 7ye bolunebilmesine bakan program *
* derleme : gcc -o program_ismi 3_3_5ve7.c                 *
***********************************************************/

#include <stdio.h>

int main(){

   int sayi;
  	
   printf("Sayi giriniz:");
   scanf("%d", &sayi);
 
   if (( !(sayi % 5) && (sayi % 7)))
      printf("Sayi 5'e tam bolunur\n");
   else if (( !(sayi % 7) && (sayi % 5)))
      printf("Sayi 7'ye tam bolunur\n");   		
   else if (( !(sayi % 7) && !(sayi % 5)))
      printf("Sayi 5'e ve 7'ye tam bolunur\n"); 
   else 
      printf("Sayi 5'e de 7'ye de bolunmez\n");
  	
   return 0; 
}
