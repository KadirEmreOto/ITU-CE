/************************************************************
* ornek   : 3-8						    *
* aciklama: do-while ile 2'ser 2'ser sayan program	    *
* derleme : gcc -o program_ismi 3_8_do_while_2ser_say.c	    *
************************************************************/

#include <stdio.h>

int main() {
   int i = 0;
	
   do {
      printf("i = %d\n", i);
      i += 2;
   } while (i <= 20);

   return 0;
}
