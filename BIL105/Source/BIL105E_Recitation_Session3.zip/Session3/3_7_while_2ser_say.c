/*******************************************************
* ornek   : 3-7					       *
* aciklama: while ile 2'ser 2'ser sayan program	       *
* derleme : gcc -o program_ismi 3_7_while_2ser_say.c   *
*******************************************************/

#include <stdio.h>

int main() {
   int i = 0;
	
   while (i <= 20) {
      printf("i = %d\n", i);
      i += 2;
   }

   return 0;
}
