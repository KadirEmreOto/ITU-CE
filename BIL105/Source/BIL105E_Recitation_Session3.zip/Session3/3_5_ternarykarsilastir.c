/************************************************************
* ornek   : 3-5	  					    *
* aciklama: uclu operator ile 2 sayinin karsilastirilmasi   *
* derleme : gcc -o program_ismi 3_5_ternary_karsilastir.c   *
************************************************************/

#include <stdio.h>

int main() {
   int i, j;
	
   printf("Farkli 2 sayi giriniz: ");
   scanf("%d %d", &i, &j);
	
   (i>j) ? printf("%d > %d\n", i, j) : printf("%d < %d\n", i, j);

   return 0;	
}
