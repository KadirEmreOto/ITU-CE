/********************************************************
* ornek   : 3-6						*
* aciklama: while ile 1 den j ye kadar sayan program	*
* derleme : gcc -o program_ismi 3_6_while_say.c		*
********************************************************/

#include <stdio.h>

int main() {
   int i = 0, j;
	
   printf("Pozitif bir tamsayi girin:");
   scanf("%d", &j);
	
   while (i < j) printf("i nin degeri: %d\n", ++i);
	
   return 0;	
}
