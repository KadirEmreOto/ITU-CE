/****************************************************************
* ornek   : 3-10						*
* aciklama: while ile girilen cumleyi buyuk harf yapan program	*
* derleme : gcc -o program_ismi 3_10_buyuk_harf.c		*
****************************************************************/

#include <stdio.h>

int main() {
	
   char c;
	
   do {
      c = getchar();	
		
      if ( (c >= 'a') && (c <= 'z') ){
         c = c - 'a';
         c = c + 'A';
         putchar(c);
      }		
   } while (c != '0');

   return 0;
}
