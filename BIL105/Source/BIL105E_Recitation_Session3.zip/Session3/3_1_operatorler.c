/********************************************************
* ornek   : 3-1                                         *
* aciklama: operator oncelikleri			*
* derleme : gcc -o program_ismi 3_1_operatorler.c       *
********************************************************/

#include <stdio.h>

int main() {
   int x, y, z;
	
   z = 1;
   x = y = z;
   printf("x = %d \t y = %d \t z = %d \n", x, y, z);
	
   x = y++ + ++z;
   printf("x = %d \t y = %d \t z = %d \n", x, y, z);

   x = y == z;
   printf("x = %d \t y = %d \t z = %d \n", x, y, z);
	
   x = y == --z;
   printf("x = %d \t y = %d \t z = %d \n", x, y, z);
	
   return 0;
}
