/************************************************************************
* ornek   : 7-2															*
* aciklama: matrix matrisinin her satirinin en buyuk elemanini bulur	*
* derleme : gcc -o program_ismi 2.c										*
************************************************************************/

#include <stdio.h>

int main()
{
    int Matrix[4][5]={
	                 {2,6,9,7,9},
	                 {7,3,8,3,6},
	                 {5,1,4,2,3},
	                 {5,2,7,3,1}
                     };
    int Max[4], row, col;
    
    printf("Matrix:\n");
    
    //her satirin max elemanlari bulunuyor ve Max dizisinde tutuluyor
	for (row = 0; row < 4; row++){
		Max[row] = Matrix[row][0];
        for (col = 1; col < 5; col++)
        	if (Max[row] < Matrix[row][col]) 
	       		Max[row]= Matrix[row][col];
    }

	//Matrix matrisi ekrana yaziliyor
    for (row = 0; row < 4; row++){
    	for (col = 0; col < 5; col++)
        	printf("%3d ", Matrix[row][col]);
        printf("\n");
    }
    
    printf("\nMax:\n");
    
    //Max dizisi ekrana yaziliyor
    for (row = 0; row < 4; row++)
    	printf("%3d ", Max[row]);
    printf("\n");

    return 0; 
}
