/************************************************************************
* ornek   : 7-3															*
* aciklama: kare matrisin transpozunu alan program						*
* derleme : gcc -o program_ismi 3.c										*
************************************************************************/

#include <stdio.h>

#define BOYUT 3


void yazdir(int[BOYUT][BOYUT]);

int main()
{
	int matris[BOYUT][BOYUT];
	int i, j;

	//matris okunuyor
   printf("%dx%d Matrisin Elemanlarini giriniz:\n\n", BOYUT, BOYUT);
   for (i = 0; i < BOYUT; i++) {
      printf("Satir %d: ", i+1);   
		for (j = 0; j < BOYUT; j++)
			scanf("%d", &matris[i][j]);
   }
	
	printf("\n\nMatris:\n"); 
	yazdir(matris);
	
	int transpoz[BOYUT][BOYUT];
	for (i = 0; i < BOYUT; i++)
		for (j = 0; j < BOYUT; j++)
			transpoz[j][i] = matris[i][j];
	
	printf("\n\nTranspoz:\n"); 
	yazdir(transpoz);
	
	return 0;
}

void yazdir(int matris[BOYUT][BOYUT])
{
	int i, j;
	
	for (i = 0; i < BOYUT; i++){
      printf("Satir %d: ", i+1);   
		for (j = 0; j < BOYUT; j++)
			printf("%d ", matris[i][j]);
		printf("\n");
	}
	printf("\n");
}
