#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE  20
#define TRIALS      3

void create_permutation(int random_array[], int seed);
void selection_sort(int sort_array[]);

int main (void) {
   int i, j, numbers[ARRAY_SIZE];

   for(j=0; j<TRIALS; j++){
   	  printf("\n\nITERARTION %d:\n", j+1);
      create_permutation(numbers, j);
      printf("Random Numbers:\n");
      for (i = 1; i <= ARRAY_SIZE; i++) {
         printf("%5d", numbers[i-1]);
		 if( !(i%10) ) printf("\n");
      };
   

      selection_sort(numbers);	    
      printf("\nSorted Numbers:\n");
      for (i = 1; i <= ARRAY_SIZE; i++) {
      	printf("%5d", numbers[i-1]);
      	if( !(i%10) ) printf("\n");
      };
   };
	return 0;
}	// main


// Create a permutation of Numbers between 0..ARRAY_SIZE-1
void create_permutation(int random_numbers[], int seed){
	int i;
	int filled[ARRAY_SIZE] = {0};
	int random_number;

        srand( time(NULL)*seed );

	for (i = 0; i < ARRAY_SIZE; i++) {
	     do {
	        random_number = rand() % ARRAY_SIZE;
	     } while (filled[random_number] == 1);
	     
	     filled[random_number] = 1;
	     random_numbers[i] = random_number;
	    } // for
};

// Sort Numbers with Selection Sort
void selection_sort(int sort_array[]){
	int current, smallest, temp, walk;

	for (current = 0; current < ARRAY_SIZE; current++) {
	     smallest = current;

	     for (walk = current + 1; walk < ARRAY_SIZE; walk++){
	         if (sort_array[walk] < sort_array[smallest])
	             smallest = walk;
	     };

        // Smallest selected: exchange with current
	    temp                     = sort_array[current];
	    sort_array[current]  = sort_array[smallest];
	    sort_array[smallest] = temp;
	    } // for current
};
