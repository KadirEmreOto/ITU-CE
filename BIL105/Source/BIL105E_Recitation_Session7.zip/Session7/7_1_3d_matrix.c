/****************************************
* ornek   : 7-1							*
* aciklama: 3 boyutlu dizi ornegi		*
* derleme : gcc -o program_ismi 1.c		*
****************************************/

#include <stdio.h>

int main()
{
	int dizi[2][3][4] = {0, 1},
		i = 0, j = 0, k = 0;
		
	for (i = 0; i < 2; i++){
		for (j = 0; j < 3; j++){
			for (k = 0; k < 4; k++)
				printf("%3d", dizi[i][j][k]);
            printf("\n");
		}
        printf("\n");
	}
	
	return 0;	
}
