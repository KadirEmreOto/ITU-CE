#include <stdio.h>
#include <string.h>

int  my_strlen( char *str );
void my_strcpy( char *str1, char *str2 );
void my_strcat( char *str1, char *str2 );
int  my_strstr( char *str1, char *str2 );
int  my_atoi( char *str );

int main(void) {
   char first_str[20] = "Tacettin ";
   char second_str[20] = "Ayar";
   char *num_str ="1234567";

   printf("\n");

   printf("strlen(%s) = %d, strlen(%s) = %d\n", first_str, my_strlen(first_str),
                                            second_str, my_strlen(second_str)); 

   printf("\n");

   printf("strcat(%s, %s) = ", first_str, second_str);
   my_strcat(first_str,second_str);
   printf("%s\n", first_str); 

   printf("\n");

   printf("strcpy(%s, %s) = ", first_str, second_str);
   my_strcpy(first_str,second_str);
   printf("%s\n", first_str); 

   printf("\n");
   printf("atoi(%s) = %d\n", num_str, my_atoi(num_str));

   printf("\n");

   return 0;
}


int my_strlen( char *str ) {
  int i;

  for (i=0; *str++; i++) ;

  return i;
}

void my_strcpy( char *str1, char *str2) {

  for( ; *str1++ = *str2++; ) ;

}

void my_strcat( char *str1, char *str2) {

  my_strcpy(str1+my_strlen(str1), str2);

}

int my_strstr( char str1[], char str2[]) {
  int i, j;
  int length_str1 = strlen(str1),
      length_str2 = strlen(str2);

  for (i=0; i < length_str1; ++i) {

    for (j=0; ( j < length_str2 ) && ( str2[j] == str1[i+j] ); j++);

    if ( j == length_str2 ) return i;

  }

  return -1;
}

int my_atoi(char *str) {
  int result = 0, digit, i;

  for(i=0; str[i]; i++) {
     digit = str[i];
     result *= 10;
     result += (digit - '0');
  }

  return result;
}
