#include <stdio.h>
#include <stdlib.h>

int main (){
   int   option;
   int   num1;
   int   num2;
   float result;

   for(;;option=0){
      printf("\n\t**********************************");
      printf("\n\t*              MENU              *");
      printf("\n\t*                                *");
      printf("\n\t*  1. ADD                        *");
      printf("\n\t*  2. SUBTRACT                   *");
      printf("\n\t*  3. MULTIPLY                   *");
      printf("\n\t*  4. DIVIDE                     *");
      printf("\n\t*  5. QUIT                       *");
      printf("\n\t*                                *");
      printf("\n\t**********************************");

      printf("\n\nPlease type your choice: ");
      scanf ("%d", &option);
   	
      if( option == 5 ) {
         printf("QUIT...\n");
         break;
      };

      switch (option) {
	     case 1: // ADD
                     printf("Please enter two integer numbers: ");
                     scanf("%d %d", &num1, &num2);
                     result = num1 + num2;   
	             break;

	     case 2: // SUBTRACT
                     printf("Please enter two integer numbers: ");
                     scanf("%d %d", &num1, &num2);
                     result = num1 - num2;   
	             break;

	     case 3: // MULTIPLY
                     printf("Please enter two integer numbers: ");
                     scanf("%d %d", &num1, &num2);
                     result = num1 * num2;   
	             break;

	     case 4: // DIVIDE
                     printf("Please enter two integer numbers: ");
                     scanf("%d %d", &num1, &num2);
                     if (num2 == 0){
	                printf("\nError: division by zero!\n");
	                printf("Please try again...\n");
	                continue;
	             } 
	             else {
                        result = num1 / num2;
                     };
	             break;

             default: 
                     printf("\nOption not available!\n");
	             return 0;
      } // switch 

      printf("Result is: %6.2f\n", result);
   } // for
	
   return 0;
}	// main

