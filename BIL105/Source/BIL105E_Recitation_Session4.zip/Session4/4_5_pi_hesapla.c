#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

int main() {
   int total;
   int  i; 
   double x, y;
   int inside;

   printf("Ornek sayisini giriniz:");
   scanf("%d", &total);

   srand( time(NULL) );

   for(i=0, inside=0; i < total; i++) {
      x = -1 + 2.0 * rand()/ RAND_MAX;
      y = -1 + 2.0 * rand()/ RAND_MAX;
      if( x*x + y*y < 1) inside++;
   }

   printf("Tahmini PI=%f\n", (inside*4.0)/total);

   return 0;
}
