#include <stdio.h>

int main (){
   int print_flag = 1;
	
   switch ( print_flag ) {

      case 1:  printf("This is case 1\n");
	             
      case 2:  printf("This is case 2\n");
	             
      default: printf("This is default\n");

   } // switch 

   return 0;
} // main 

