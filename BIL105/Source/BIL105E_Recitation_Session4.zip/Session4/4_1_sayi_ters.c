#include <stdio.h>

int main(){
   int sayi;
	
   printf("Sayiyi giriniz:");
   scanf("%d", &sayi);
	
   int i = sayi, j;
    
   while (i > 0){
      j = i % 10;
      printf("%d", j);
      i /= 10;
   }
    
   printf("\n");

   return 0;
}
