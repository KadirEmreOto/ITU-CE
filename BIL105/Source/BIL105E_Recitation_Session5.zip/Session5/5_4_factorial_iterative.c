#include <stdio.h>

long factorial (int n);

int main (void) {
   int n;

   printf("Sayiyi giriniz:");
   scanf("%d", &n);
     
   if( n>=0 ) {
      printf( "%d! = %d\n", n, factorial(n) );
   }
   else {
      printf( "Sayi(%d) negatif olamaz!\n", n );
   };

   return 0;
}; // main()

long factorial (int n){
	long factN = 1;

	for (; n >= 1; n--)
	    factN *= n;

	return factN;
} // factorial()
