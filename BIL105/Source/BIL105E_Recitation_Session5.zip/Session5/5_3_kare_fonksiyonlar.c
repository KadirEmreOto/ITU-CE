/********************************************************
* ornek   : 5-3											*
* aciklama: fonksiyonlarla karenin cevresini hesaplar	*
* derleme : gcc -o program_ismi 5_3_kare_fonksiyonlar.c						*
********************************************************/
 
 #include <stdio.h>
 
 void yaz(int a){
 	printf("Karenin cevresi = %d\n",a);	
 }
 
 void hesapla(int a){
 	yaz(4*a);	
 }
 
 void devam(int a){
 	hesapla(a);
 }
 
 int main(){
 	int a;
 	
 	printf("Karenin kenarini girin:");
 	scanf("%d", &a);
 	devam(a);
 	
	return 0;	
 }
