/****************************************
* ornek   : 8-3							*
* aciklama: * ve & iliskisi				*
* derleme : gcc -o program_ismi 3.c		*
****************************************/

#include <stdio.h>

int main()
{ 
	int sayi = 0, *ptr = &sayi;
	
	printf("sayi: %d, \t\tadresi: %p\n", sayi, &sayi);
	printf("*ptr: %d, \t\tptr: %p\t &ptr: %p\n", *ptr, ptr, &ptr);
	printf("*&ptr: %p\t&*ptr: %p\n", *&ptr, &*ptr);
	
	return 0;
}
