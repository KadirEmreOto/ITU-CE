/****************************************
* ornek   : 8-2							*
* aciklama: pointera pointer ornegi		*
* derleme : gcc -o program_ismi 2.c		*
****************************************/

#include <stdio.h>

int main()
{
	int n = 44;
		
	printf("n     = %d \t &n   = %x\n", n, &n);

	int* pn = &n;

	printf("*pn   = %d \t pn   = %x \t &pn  = %x\n", *pn, pn, &pn);
	
	int** ppn = &pn;
	printf("**ppn = %d \t *ppn = %x \t  ppn = %x \t &ppn = %x\n", **ppn, *ppn, ppn, &ppn);

	return 0;
}
