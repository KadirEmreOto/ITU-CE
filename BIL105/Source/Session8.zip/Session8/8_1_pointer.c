/****************************************
* ornek   : 8-1							*
* aciklama: pointer ornegi				*
* derleme : gcc -o program_ismi 1.c		*
****************************************/

#include <stdio.h>

int main()
{
	int n = 44;
		
	printf("n   = %d \t &n = %x\n", n, &n);

	int* pn = &n;

	printf("*pn = %d \t pn = %x \t pnp = %p \t &pn = %x\n", *pn, pn, pn, &pn);

	return 0;
}
