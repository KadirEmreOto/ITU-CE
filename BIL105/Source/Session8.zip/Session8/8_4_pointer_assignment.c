/****************************************
* ornek   : 8-4							*
* aciklama: pointerlarla atama ornegi	*
* derleme : gcc -o program_ismi 4.c		*
****************************************/

#include <stdio.h>

int main()
{
	int count = 0, *temp, sum = 0;
	
	temp  = &count;
	*temp = 20;
	temp  = &sum;
	*temp = count;
	
	printf("count: %d, temp: %d, sum: %d\n", count, *temp, sum);
	
	return 0;
}
