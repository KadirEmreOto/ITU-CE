/************************************************************
* ornek   : 8-5												*
* aciklama: NULL ve void pointer ornegi						*
* 			NULL atanmis bir pointer hicbir yeri gostermez	*
* derleme : gcc -o program_ismi 5.c							*
************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *ptr = (int *)malloc(sizeof(int));
	void *vPtr = NULL;
	
	printf("ptr pointerinin gosterdigi:  %d\ticerigi: %x\tadresi: %x\n",*ptr,ptr,&ptr);

	vPtr = ptr;
	printf("vPtr pointerinin gosterdigi: %d\ticerigi: %x\tadresi: %x\n",*(int *)vPtr,vPtr,&vPtr);
	
	return 0;	
}
