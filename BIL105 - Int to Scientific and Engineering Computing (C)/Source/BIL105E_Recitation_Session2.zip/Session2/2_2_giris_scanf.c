/**************************************************
* ornek   : 2-2                                   *
* aciklama: kullanicidan giris almak              *
* derleme : gcc -o program_ismi 2_2_giris_scanf.c *
**************************************************/

#include <stdio.h>

int main() {
  int a, b;

  printf("Toplanacak sayilari giriniz: ");
  scanf("%d %d", &a, &b);
  printf("Toplam = %d\n", a + b);

  return 0;
}
