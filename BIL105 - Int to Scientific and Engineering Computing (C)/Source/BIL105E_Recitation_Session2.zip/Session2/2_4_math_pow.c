/***************************************************
* ornek   : 2-4                                    *
* aciklama: matematik kutuphanesi kullanimi        *
* derleme : gcc -lm -o program_ismi 2_4_math_pow.c *
***************************************************/

#include <stdio.h>
#include <math.h>

int main() {
  float  x = 25;
  double y;

  y = pow(x,2);
  printf("y = %20.2f\n", y);

  return 0;
}
