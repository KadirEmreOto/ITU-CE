/**********************************************
* ornek   : 2-1                               *
* aciklama: toplama ornegi                    *
* derleme : gcc -o program_ismi 2_1_toplama.c *
**********************************************/

#include <stdio.h>

int main() {	
  int x = 5, y = 2, z;

  /*Bu satirlar 
    dikkate alinmaz*/

  //Bu satir da alinmaz..

  z = x + y; //toplama islemi bu satirda
  printf("x + y = %d\n", z);

  return 0;
}
