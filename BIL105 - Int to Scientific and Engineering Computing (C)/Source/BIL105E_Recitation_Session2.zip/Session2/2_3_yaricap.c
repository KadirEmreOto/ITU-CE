/******************************************************************************
* ornek   : 2-3                                                               *
* aciklama: yaricapi verilen cemberin cevresini ve alanini hesaplayan program * 
* derleme : gcc -o program_ismi 2_3_yaricap.c                                 *
******************************************************************************/

#include <stdio.h>

#define PI 3.1415

int main() {
   float yaricap, cevre, alan;
	
   printf("Yaricapi giriniz: ");
   scanf("%f", &yaricap);
	
   cevre = (2 * yaricap) * PI;
   alan = PI * yaricap * yaricap;
	
   printf("Cemberin cevresi = %7.2f\n", cevre);
   printf("Dairenin alani   = %7.2f\n", alan);

   return 0;
}
