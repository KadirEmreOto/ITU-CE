/***************************************************************************
* ornek   : 2-5                                                            *
* aciklama: iki kisa kenari verilen dik ucgenin hipotenusunu bulan program *    
* derleme : gcc -lm -o program_ismi 2_5_hipotenus.c                        *
***************************************************************************/

#include <stdio.h>
#include <math.h>

int main() {
   float kenar1, kenar2, hipotenus;
   float hipotenus_ceil, hipotenus_floor;

   printf("Ucgenin kenarlarini giriniz: ");
   scanf("%f %f", &kenar1, &kenar2);

   hipotenus = sqrt((kenar1 * kenar1) + (kenar2 * kenar2));
	
   printf("Ucgenin hipotenusu = %f\n", hipotenus);
	
   hipotenus_ceil = ceil(hipotenus);
   printf("ceil ile Ucgenin hipotenusu = %f\n", hipotenus_ceil);
	
   hipotenus_floor = floor(hipotenus);
   printf("floor ile Ucgenin hipotenusu = %f\n", hipotenus_floor);

   return 0;	
}
