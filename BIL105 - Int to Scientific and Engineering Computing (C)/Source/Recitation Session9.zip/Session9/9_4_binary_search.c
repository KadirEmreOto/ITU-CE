#include <stdio.h>

#define MAX_ARY_SIZE 12

//	Prototype Declaration 
int binarySearch (int list[], int*  endPtr, int target);

int main (void) {
   // Local Declarations 
   int locn;
   int  target;
   
   //sorted array
   int arr[MAX_ARY_SIZE] = {  4,  7,  8, 10, 
	                          14, 21, 22, 36, 
	                          62, 77, 81, 91 };

   // Statements 
   printf("Data: ");
   for (locn = 0; locn < MAX_ARY_SIZE; locn++) printf("%3d", arr[locn]);	
	
   printf("\n\nEnter a key for search: ");
   scanf("%d", &target);
   	
   do {
   	  locn=binarySearch (arr, &(arr[MAX_ARY_SIZE - 1]), target);
      if ( locn >= 0 )
	       printf("%3d found at location: %2d\n", target, locn);
	   else
	       printf("%3d NOT found!\n", target);

	   printf("\nEnter next key <-1> to quit: ");
	   scanf("%d", &target);	
   } while (target != -1);

	printf("End of search.\n");
	return 0;
}	// main 

int binarySearch (int list[], int *endPtr, int target) {
   // Local Declarations 
   int* firstPtr;
   int* midPtr;
   int* lastPtr;

   // Statements
   firstPtr = list;
   lastPtr  = endPtr;
   while (firstPtr <= lastPtr) {
	    midPtr = firstPtr + (lastPtr - firstPtr) / 2;
	    if (target > *midPtr)
	       // look in upper half
	       firstPtr = midPtr + 1;
	    else if (target < *midPtr)
	       // look in lower half
	       lastPtr = midPtr - 1;
	    else
	       // found equal: force exit
	       firstPtr = lastPtr + 1;
	   } // end while

	if (target == *midPtr) return (midPtr-list);
    else return -1;
}	// binarySearch
