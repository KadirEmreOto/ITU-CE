#include <stdio.h>

#define ROWS 3
#define COLS 4

int main() {
   int i, j;
   int dizi[ROWS][COLS] = {
	                        {11, 12, 13, 14},
	                        {21, 22, 23, 24},   
	                        {31, 32, 33, 34}   
	                       };
   int *rows[ROWS];

   for(i=0; i<ROWS; i++)
	   rows[i] = &dizi[0][0] + i * COLS;
   	

   for (i = 0; i < ROWS; i++){
      printf("\nDIZI[%d]: ", i);
	  for (j = 0; j < COLS; j++){
         printf("%3d", dizi[i][j]);
      }
	  printf("\n");

      printf("ROWS[%d]: ", i);
      for (j = 0; j < COLS; j++){
         printf("%3d", rows[i][j]);
      }
	  printf("\n");
   }
   	
	return 0;	
}
