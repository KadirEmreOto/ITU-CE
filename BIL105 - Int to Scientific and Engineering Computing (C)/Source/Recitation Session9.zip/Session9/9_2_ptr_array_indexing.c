#include <stdio.h>
#include <stdlib.h>

int main() {
	int *dizi, i, uzunluk;
	
	printf("Dizinin uzunlugunu girin: ");
	scanf("%d", &uzunluk);
	
   if (!(dizi = malloc(sizeof(int) * uzunluk))) {
	   printf("Bellek hatasi!\n"); 
	   exit(1);
   }
	   

    printf("\nDizi elemanlarini giriniz: ");
	for (i = 0; i < uzunluk; i++) scanf("%d", &dizi[i]);
	
	
	printf("\nGirilen dizi elemanlari: ");
	for (i = 0; i < uzunluk; i++)
		printf("%d ", dizi[i]);
	printf("\n");
	
	printf("\nBellek bosaltiliyor...\n");
	free(dizi);
	
	return 0;	
}
